﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IGatePatni.WinForms.WinApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnclose.Click += new EventHandler(button1_Click);
        }

        private void btnwelcome_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome " + txtname.Text + " !!!");
        }

        private void btnwelcome_MouseEnter(object sender, EventArgs e)
        {
            Button b = sender as Button;
            b.BackColor = Color.Yellow;
            b.ForeColor = Color.OrangeRed;
        }

        private void btnwelcome_MouseLeave(object sender, EventArgs e)
        {
            Button b = sender as Button;
            b.BackColor = SystemColors.Control;
            b.ForeColor = Color.Black;
        }
    }
}
